package com.example.coriander

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
